<?php
header("Location: magicegg.php");