<?php ?>
<?php  include "header.php"?>
<link href="css/farm.css?t=<?php echo  time();?>" rel="stylesheet" />

<div class="container farrm" style="">
    <div class="row" id="play">
        <h2 style="margin-bottom: 0px">Farm</h2>

    </div> <div class="row farm" id="play">
        <h2 style="margin: 100px">Coming Soon</h2>

    </div>
    </section>
</div>

<?php  include "footer.php"?>
<script src="js/farm.js"></script>
