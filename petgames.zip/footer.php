<?php
?>
<!-- ============== DIVIDER ============== -->
<div id="footer">
    <div class="Divider">
        <hr class="Divider-rule" />
    </div>

    <!-- ============== FOOTER =============== -->
    <div class="row pattern-dark">
        <footer class="container footer">

            <div class="row">
                <p class="copyright">Copyright &copy; 2021 PET GAMES.</p>
            </div>
        </footer>
    </div>
</div>
</div>

<!-- ============== SCRIPTS =============== -->
<!--<script src="js/jquery-1.12.4.min.js"></script>-->
<script src="https://code.jquery.com/jquery-2.2.4.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-message-box@3.2.2/dist/messagebox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/web3/1.4.0/web3.min.js"></script>
<script src="js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="js/header.js?t=<?php echo  time();?>"></script>
<script src="js/app.js?t=<?php echo  time();?>"></script>
<script src="js/jquery-mobile-custom/jquery.mobile.custom.min.js"></script>
</body>

</html>
