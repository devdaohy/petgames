<?php
header("Location: magicegg");