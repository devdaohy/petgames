<?php
header("Location: magicegg");