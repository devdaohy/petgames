<?php ?>
<?php  include "header.php"?>
<link href="css/magicegg.css?t=<?php echo  time();?>" rel="stylesheet" />

                <div class="container egg" style="margin-top: 2rem">
                <div class="row" id="play">
                    <h2 style="margin-bottom: 0px">MAGIC EGG</h2>
                </div>
                <div class="row items-container item-egg">
                    <div id="item-1" class="col-xs-5 col-sm-3 gallery-item item-1 thumbnail-50 background-config" style="background-image: url(img/imageframe/imageframe-1.png); " data-toggle="modal" data-target="#shop-modal">
                        <img src="img/egg/1-egg.png" class="image-egg-magic" alt="Avatar Pet" width="400" height="750" />
                         <div class="panel-item__text">
                            <h4 class="panel-item__title">Water Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                            <div class="div-amount">
<!--                                <form>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </form>-->
                            </div>
                        </div>
                        <a id="egg-water" xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span  style="font-size: 20px">Buy</span>
                            </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>
                    <div id="item-2" class="col-xs-5  col-sm-3 col-sm-offset-1  gallery-item item-2 thumbnail-50 background-config" style="background-image: url(img/imageframe/imageframe-2.png);" data-toggle="modal" data-target="#shop-modal">
                        <img src="img/egg/2-egg.png" class="image-egg-magic" alt="Avatar Pet" width="440" height="750"  />
                         <div class="panel-item__text">
                            <h4 class="panel-item__title">Fire Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                              <div class="div-amount">
<!--                                <div>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </div>-->

                            </div>
                        </div>
                        <a id="egg-fire" xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span  style="font-size: 20px">Buy</span>
                              </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>
                    <div id="item-3" class="col-xs-5 col-sm-3 col-sm-offset-1 gallery-item item-3 thumbnail-50 background-config" style=" background-image: url(img/imageframe/imageframe-3.png);" data-toggle="modal" data-target="#shop-modal">

                        <img src="img/egg/3-egg.png" class="image-egg-magic" alt="Avatar Pet" width="440" height="750"/>
                        <div class="panel-item__text">
                            <h4 class="panel-item__title">Wood Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                              <div class="div-amount">
<!--                                <div>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </div>-->

                            </div>
                        </div>
                        <a id="egg-wood" xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span  style="font-size: 20px">Buy</span>
                              </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>
                    <div id="item-4" class="col-xs-5 col-sm-3  col-sm-offset-1 gallery-item  item-4  thumbnail-50 background-config" style=" background-image: url(img/imageframe/imageframe-4.png);" data-toggle="modal" data-target="#shop-modal">
                        <img src="img/egg/4-egg.png" class="image-egg-magic" alt="Avatar Pet" width="440" height="750"/>
                       <div class="panel-item__text">
                            <h4 class="panel-item__title">Metal Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                              <div class="div-amount">
<!--                                <div>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </div>-->
                            </div>
                        </div>
                        <a id="egg-metal" xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span id="egg-metal" style="font-size: 20px">Buy</span>
                              </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>
                </div>
                <div class="row items-container item-egg">
                    <div id="item-5" class="col-xs-5 col-sm-3 gallery-item item-1 thumbnail-50 background-config" style="background-image: url(img/imageframe/imageframe-5.png);" data-toggle="modal" data-target="#shop-modal">
                        <img src="img/egg/5-egg.png" class="image-egg-magic" alt="Avatar Pet" width="440" height="750" />
                        <div class="panel-item__text">
                            <h4 class="panel-item__title">Earth Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                              <div class="div-amount">
<!--                                <div>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </div>-->

                            </div>
                        </div>
                        <a id="egg-earth" xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span  style="font-size: 20px">Buy</span>
                              </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>
                    <div id="item-6" class="col-xs-5  col-sm-3 col-sm-offset-1 gallery-item   item-2  thumbnail-50  background-config " style=" background-image: url(img/imageframe/imageframe-6.png);" data-toggle="modal" data-target="#shop-modal">
                        <img src="img/egg/0-egg.png" class="image-egg-magic" alt="Avatar Pet" width="440" height="750"/>
                       <div class="panel-item__text">
                            <h4 class="panel-item__title">Random Egg</h4>
                            <p style="text-align: center"> <img src="img/logo.png" class="imagemoney"/></img></p>
                            <div class="div-amount">
<!--                                <div>-->
<!--                                    <label>Amount</label>-->
<!--                                    <input type="number" class="amount" value="1"/>-->
<!--                                </div>-->

                            </div>
                        </div>
                        <a  id="egg-random"  xmlns="http://www.w3.org/1999/xhtml" class="button-game">
                            <span class="button-game-bg-left-buy"></span>
                            <span class="button-game-bg-mid">
                                <span style="font-size: 20px">Buy</span>
                              </span>
                            <span class="button-game-bg-right-buy"></span>
                        </a>
                    </div>

                </div>
        </section>
    </div>

<?php  include "footer.php"?>
<script src="js/magicegg.js?t=<?php echo  time();?>"></script>
